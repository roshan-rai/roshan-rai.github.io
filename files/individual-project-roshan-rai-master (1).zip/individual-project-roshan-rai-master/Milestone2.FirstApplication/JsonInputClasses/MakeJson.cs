﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Milestone2.FirstApplication.JsonInputClasses
{
    public class MakeJson
    {

        public string Name { get; set; }
        public string CEO { get; set; }
        public string FoundingYear { get; set; }
        public string Website { get; set; }
    }

}
